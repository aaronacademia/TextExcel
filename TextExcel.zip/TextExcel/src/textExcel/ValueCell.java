package textExcel;
/*Aaron Academia
 * March 2, 2023
 * class for creating cells solely with numbers
 */

public class ValueCell extends RealCell{
	//returns parsed double 10 characters wide
	public String abbreviatedCellText() {
		String paddedText = getDoubleValue() + "          ";
		return paddedText.substring(0, 10);
	}
	//returns original number in text
	public String fullCellText() {
		return super.fullCellText();
	}
	//parses text into double
	public double getDoubleValue() {
		return super.getDoubleValue();
	}
	//constructor
	public ValueCell(String num) {
		super(num);
	}
	
}
