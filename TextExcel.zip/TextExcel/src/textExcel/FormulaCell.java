package textExcel;
/*Aaron Academia
 * March 2, 2023
 * class for parsing cells with formulas
 */

public class FormulaCell extends RealCell{

	private Spreadsheet sheet;
	//return calculated formula 10 characters wide
	public String abbreviatedCellText() {
		String paddedText = getDoubleValue() + "          ";
		return paddedText.substring(0, 10);
	}
	//return original formula with parentheses
	public String fullCellText() {
		return super.fullCellText();
	}
	//return calculated formula
	public double getDoubleValue() {
		//split formula by spaces
		String[] splitFormula = fullCellText().split(" ");
		//checks for "SUM" or "AVG" and returns calculation of specified cell range
		if (fullCellText().toUpperCase().contains("SUM") || fullCellText().toUpperCase().contains("AVG"))
			return getSumOrAvg(splitFormula);
		//makes first value of formula the return value
		double num = getCellValue(splitFormula[1]);
		//calculates each operation depending on the length
		//of the formula, incrementing by 2 for the operator
		for (int i = 2; i < splitFormula.length; i+=2) {
			String operator = splitFormula[i];
			//runs a series of conditionals and calculates the specific operation
			if (operator.equals("+"))
				num += getCellValue(splitFormula[i+1]);
			if (operator.equals("-"))
				num -= getCellValue(splitFormula[i+1]);
			if (operator.equals("*"))
				num *= getCellValue(splitFormula[i+1]);
			if (operator.equals("/"))
				num /= getCellValue(splitFormula[i+1]);
		}
		return num;
	}
	//constructor
	public FormulaCell(String formula, Spreadsheet sheet) {
		super(formula);
		this.sheet = sheet;
	}
	//returns calculations for sum and average of cell ranges
	public double getSumOrAvg(String[] formula) {
		//creates initial values for sum and count for average
		double sum = 0.0;
		int count = 0;
		//splits cell ranges by the dash
		String[] cellRange = formula[2].split("-");
		//creates cell locations for the upper left and lower right cells on Spreadsheet
		Location topLeft = new SpreadsheetLocation(cellRange[0]);
		Location bottomRight = new SpreadsheetLocation(cellRange[1]);
		//for loops sizes depend on cell ranges of rows and cols
		for (int row = topLeft.getRow(); row <= bottomRight.getRow(); row++) {
			for (int col = topLeft.getCol(); col <= bottomRight.getCol(); col++) {
				//creates a new location for each increment of the nested for loops
				Location cellLoc = new SpreadsheetLocation((char)(col + 'A') + Integer.toString(row+1));
				//casts Cell from private field into RealCell and calls getDoubleValue()
				RealCell cell = (RealCell) sheet.getCell(cellLoc);
				sum += cell.getDoubleValue();
				count++;
			}
		}
		//if formula contains "SUM" return statement is calculated sum value
		if (formula[1].equalsIgnoreCase("sum"))
			return sum;
		//if not the method return is the sum/number of Cells
		else return sum/count;
	}
	//helper method for determining Cell values and parsing Strings
	public double getCellValue(String cell) {
		//determines if the first character of the String is a letter
		if (Character.isLetter(cell.charAt(0))) {
			//creates a new location using the input and casts it into a RealCell
			Location cellLoc = new SpreadsheetLocation(cell);
			return ((RealCell) sheet.getCell(cellLoc)).getDoubleValue();
		}
		//returns parsed number if the input isn't a Cell
		else return Double.parseDouble(cell);
	}
	
}
