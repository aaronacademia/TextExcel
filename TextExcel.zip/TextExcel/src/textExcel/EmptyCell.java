package textExcel;
/*Aaron Academia
 * February 22, 2023
 * class for creating new cells or clearing cells
 */

public class EmptyCell implements Cell {
	
	private String noText;
	
	// text for spreadsheet cell display, must be exactly length 10
	public String abbreviatedCellText() {
		return "          ";
	}
	
	 // text for individual cell inspection, not truncated or padded
	public String fullCellText() {
		return noText;
	}
	//constructor
	public EmptyCell() {
		noText = "";
	}
	
}
