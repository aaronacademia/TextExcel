package textExcel;
/*Aaron Academia
 * March 2, 2023
 * class for creating and changing cells with text
 */

public class TextCell implements Cell {

	private String text;
	
	//returns original text 10 characters wide
	public String abbreviatedCellText() {
		//if text is over 10 characters excluding quotation marks method 
		//returns substring of 10 characters without quotation marks
		if (text.length() >= 12) {
		return text.substring(1,11);
		}
		//otherwise creates a String and spaces are added depending on the length
		else {
			String addSpaces = text.substring(1, text.length()-1);
			for (int i = 0; i < 12-text.length(); i++)
				addSpaces+= " ";
			return addSpaces;
		}
	}

	//returns full text including quotation marks
	public String fullCellText() {
		return text;
	}
	//constructor
	public TextCell(String text) {
		this.text = text;
	}

}
