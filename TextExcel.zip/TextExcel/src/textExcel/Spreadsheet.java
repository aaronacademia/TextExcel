package textExcel;
/*Aaron Academia
 * February 22, 2023
 * class definition for Spreadsheet
 */

public class Spreadsheet implements Grid
{
	private Cell[][] userGrid = new Cell[20][12];
	
	@Override
	public String processCommand(String command)
	{
		String output = "";
		//splits command by the spaces with the max length of 3
		String[] splitCommand = command.split(" ", 3);
		//conditional is true command is not split
		if (splitCommand.length == 1) {
			//conditional is true if user wants to clear the whole grid
			if (command.equalsIgnoreCase("clear")) {
				//turns every Cell into an EmptyCell
				makeEmpty();
				output = getGridText();
				//actions for cell inspection
			} else {
				//creates a new cell location and returns fullCellText of specific Cell
				Location cellLoc = new SpreadsheetLocation(command);
				output = getCell(cellLoc).fullCellText();
			}
		}
		//conditional is true if user wants to clear a specific cell
		if (splitCommand.length == 2) {
			//turns specific Cell into an EmptyCell depending on the inputted location
			Location cellLoc = new SpreadsheetLocation(splitCommand[1]);
			userGrid[cellLoc.getRow()][cellLoc.getCol()] = new EmptyCell();
			output = getGridText();
		}
		//conditional is true when user assigns specific cell
		else if (splitCommand.length > 2) {
			//creates location which will always be the first part of the command
			Location cellLoc = new SpreadsheetLocation(splitCommand[0]);
			//assigns a Cell with a percent
			if (command.contains("%")) {
				userGrid[cellLoc.getRow()][cellLoc.getCol()] = new PercentCell(splitCommand[2]);
				output = getGridText();
			}
			//assigns a Cell only with text
			else if (command.contains("\"")) {
				userGrid[cellLoc.getRow()][cellLoc.getCol()] = new TextCell(splitCommand[2]);
				output = getGridText();
			}
			//assigns a Cell with a formula
			else if (command.contains(")")){
				userGrid[cellLoc.getRow()][cellLoc.getCol()] = new FormulaCell(splitCommand[2], this);
				output = getGridText();
			//assigns a Cell with a number value
			}else {
				userGrid[cellLoc.getRow()][cellLoc.getCol()] = new ValueCell(splitCommand[2]);
				output = getGridText();
			}
		}
		return output;
		
	}

	@Override
	public int getRows()
	{
		return 20;
	}

	@Override
	public int getCols()
	{
		return 12;
	}

	@Override
	public Cell getCell(Location loc) 
	{
		return userGrid[loc.getRow()][loc.getCol()];
	}

	@Override
	public String getGridText()
	{
		//adds first spaces with column letters and 9 spaces in between each divider
		String grid = "   ";
		for (char col = 'A'; col <= 'L'; col++) {
			grid+= "|" + col + "         ";
		}
		grid+= "|\n";
		//adds rows 1 through 9 with 2 spaces after row number
		for (int row = 0; row < 9; row++) {
			grid+= row+1 + "  ";
			for (int col = 0; col < 12; col++) {
				//adds divider with 10-character-wide value of Cell
				grid+= "|" + userGrid[row][col].abbreviatedCellText();
			}
			grid+="|\n";
		}
		//adds rows 10 through 20 with 1 space after row number
		for (int row = 9; row < 20; row++) {
			grid+= row+1 + " ";
			for (int col = 0; col < 12; col++) {
				//adds divider with 10-character-wide value of Cell
				grid+= "|" + userGrid[row][col].abbreviatedCellText();
			}
			grid+="|\n";
		}
		
		return grid;
	}
	//creates a new spreadsheet containing EmptyCells
	public Spreadsheet() {
		makeEmpty();
	}
	//helper method for turning entire spreadsheet into EmptyCells
	public void makeEmpty() {
		for (int i = 0; i < 20; i++)
			for (int j = 0; j < 12; j++)
				userGrid[i][j] = new EmptyCell();
	}
	
}
