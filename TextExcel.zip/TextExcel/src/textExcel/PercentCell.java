package textExcel;
/*Aaron Academia
 * March 2, 2023
 * class for creating and parsing cells with percentages
 */

public class PercentCell extends RealCell{
	//returns int version of the percent and adds a percent sign 10 - 10 characters wide
	public String abbreviatedCellText() {
		//takes substring of number before the decimal point and adds a percent sign after
		String paddedText = super.fullCellText().substring(0, super.fullCellText().indexOf(".")) + "%         ";
		return paddedText.substring(0, 10);
	}
	//returns original number without percent sign divided by 100
	public String fullCellText() {
		//creates new String and parses it into a double without the percent sign
		String original = super.fullCellText();
		double num = Double.parseDouble(original.substring(0, original.length()-1));
		return num/100 + "";
	}
	//returns value from fullCellText() multiplied by 100
	public double getDoubleValue() {
		return Double.parseDouble(fullCellText())*100;
	}
	//constructor
	public PercentCell(String percent) {
		super(percent);
	}
	
}
