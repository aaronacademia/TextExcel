package textExcel;
/*Aaron Academia
 * February 22, 2023
 * client code for taking in commands and printing processCommand results
 */

import java.io.FileNotFoundException;
import java.util.Scanner;

// Update this file with your own code.

public class TextExcel
{

	public static void main(String[] args)
	{
		//creates Scanner and Spreadsheet for user
		Scanner userInput = new Scanner(System.in);
    	Spreadsheet spreadsheet = new Spreadsheet();
    	//asks for command and assigns it to a String
    	System.out.print("Command: ");
    	String command = userInput.nextLine();
    	//takes commands until user enters "quit"
	    while (!command.equalsIgnoreCase("quit")) {
	    	//prints out return from processCommand() and requests new command
	    	System.out.print(spreadsheet.processCommand(command)+"\nCommand: ");
	    	command = userInput.nextLine();
	    }
	    userInput.close();

	}
}