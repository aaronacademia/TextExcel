package textExcel;
/*Aaron Academia
 * Feburary 22, 2023
 * cell location object/class
 */

public class SpreadsheetLocation implements Location
{
	private String cellName;
	
    @Override
    public int getRow()
    {
    	//parses the cell location's number into an int and subtracts 1
        return Integer.parseInt(cellName.substring(1))-1;
    }

    @Override
    public int getCol()
    {
    	//subtracts the ASCII value from the cell location's letter
        return cellName.toUpperCase().charAt(0)-'A';
    }
    
    //Constructor
    public SpreadsheetLocation(String cellName)
    {
        this.cellName = cellName;
    }

}
