package textExcel;
/*Aaron Academia
 * March 2, 2023
 * abstract superclass for ValueCell, PercentCell, and FormulaCell
 */

public abstract class RealCell implements Cell{
	
	private String cellText;
	//returns the original text 10 characters wide
	public String abbreviatedCellText() {
		String paddedText = cellText + "          ";
		return paddedText.substring(0, 10);
	}
	//returns original text
	public String fullCellText() {
		return cellText;
	}
	//returns original value parsed into a double
	public double getDoubleValue() {
		return Double.parseDouble(cellText);
	}
	//constructor which is instantiable
	public RealCell(String text) {
		cellText = text;
	}
	
}
